import express from 'express';
import webpack from 'webpack';
import path from 'path';
import config from '../webpack.config.dev';
import open from 'open';

/* eslint-disable no-console */
/* eslint-disable no-debugger */

const port = process.env.PORT || 3000;
const environment = process.env.NODE_ENV || 'development';
const app = express();

if (environment == 'development'){
    const compiler = webpack(config);
    app.use(require('webpack-dev-middleware')(compiler, {
      noInfo: true,
      publicPath: config.output.publicPath
    }));
     
    app.use(require('webpack-hot-middleware')(compiler));
    
    // TODO: move all routes out to router.js
    app.get('/test', function(req, res) {
      res.send({status: 'success'});
    }); 

    app.get('*', function(req, res) {
        res.sendFile(path.join( __dirname, '../server/index.html'));
    }); 

} else {
    app.use(express.static('dist'));
    debugger;
    app.get('*', function(req, res) {
      debugger;
        res.sendFile(path.join(__dirname, '../dist/index.html'));
    });
} 

app.listen(port, function(err) {
  if (err) {
    console.log(err);
  } else {
    console.log(`Server is running in ${environment} on port: ${port}`);
 
    if (environment === 'development') open(`http://localhost:${port}`);
  } 
});
