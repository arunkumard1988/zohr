import React, { Component } from 'react';
import { Link,Switch,Router, Route } from 'react-router-dom';
import { history } from './helpers';
//import { alertActions } from '../_actions';
//import { PrivateRoute } from '../_components';
import { HeaderPage } from './common/HeaderPage';
import { LoginPage } from './components/LoginPage';
import { OnboardingPage } from './components/OnboardingPage';
import {NotFoundPage} from './components/NotFoundPage';
import { HomePage } from './components/HomePage';
import { Dashboard } from './common/DashboardPage';
import logo from './assets/images/logo.svg';
import './assets/styles/css/app.css';
class App extends Component {

  render() {	 
    return (
      <div className="App">   
			<Router history={history}>
				<div>		
					<Switch>
						<Route exact path="/login" component={LoginPage}/>
						<Route path="/" component={Dashboard}/>
						<Route component={NotFoundPage} />
					</Switch>					
				</div>
			</Router>			
		</div>
		
    );
  }
}
/* function mapStateToProps(state) {
    const { alert } = state;
    return {
        alert
    };
} */
//const connectedApp = connect(mapStateToProps)(App);
//export { connectedApp as App }; 
export default App;
