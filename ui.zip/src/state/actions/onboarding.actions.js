import { onboardingConstants } from '../constants';
import { onboardingService } from '../../api';
import { alertActions } from './';
import { history } from '../../helpers';

export const onboardingActions = {
    addRealm,
    addService	
};

function addRealm(realmname) {
    return dispatch => {
        dispatch(request({ realmname }));
        onboardingService.addRealm(realmname)
            .then(
                realm => { 				 
                    dispatch(success(realm));
                    //history.push('/HomePage');
                },
                error => {
                    dispatch(failure(error));
                    dispatch(alertActions.error(error));
                }
            );
    };
    function request(realm) { return { type: onboardingConstants.REALM_REQUEST, realm }; }
    function success(realm) { return { type: onboardingConstants.REALM_SUCCESS, realm }; }
    function failure(error) { return { type: onboardingConstants.REALM_FAILURE, error }; }
}

function addService(realmname,servicename) {
    return dispatch => {
        dispatch(request({ realmname,servicename }));
        onboardingService.addService(realmname,servicename)
            .then(
                realm => { 				 
                    dispatch(success(realm));
                    //history.push('/HomePage');
                },
                error => {
                    dispatch(failure(error));
                    dispatch(alertActions.error(error));
                }
            );
    };
    function request(realm) { return { type: onboardingConstants.SERVICE_REQUEST, realm }; }
    function success(realm) { return { type: onboardingConstants.SERVICE_SUCCESS, realm }; }
    function failure(error) { return { type: onboardingConstants.SERVICE_FAILURE, error }; }
}
 