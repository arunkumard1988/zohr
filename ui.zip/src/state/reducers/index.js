import { combineReducers } from 'redux';
import { alert } from './alert.reducer';

// we will be adding more here
const rootReducer = combineReducers({
  alert
});

export default rootReducer;