import React from 'react';
import { NavLink } from 'react-router-dom';
import { connect } from 'react-redux';
import logo from './../assets/images/deluxe-red.svg'; 
class HeaderPage extends React.Component {

    constructor(props) {
        super(props); 
	} 
    render() {
       // const { user, users } = this.props; 		
        return (<nav className="navbar is-transparent">
   <div className="container is-fluid">
      <div className="navbar-brand">
         <a className="navbar-item" href="#">
         <img src={logo} alt="Deluxe" className="logo"/>
         <span className="product">IAM</span></a>
         <div className="navbar-burger burger" data-target="navbarExampleTransparentExample">
            <span/>
            <span/>
            <span/>
         </div>
      </div>
      <div>
         <div className="navbar-start">
            <NavLink exact activeClassName="active" to="/Onboarding" className="navbar-item">Onboarding</NavLink>
            <NavLink exact activeClassName="active" to="/HomePage" className="navbar-item">Policy</NavLink>
            <NavLink exact activeClassName="active" to="/AclPage" className="navbar-item" >ACL</NavLink>
            <NavLink exact activeClassName="active" to="/WhiteListPage" className="navbar-item">Whitelist</NavLink>
            <NavLink exact activeClassName="active" to="/UploadPage" className="navbar-item">Import/Export</NavLink>
            <NavLink exact activeClassName="active" to="/ValidatePage" className="navbar-item">Validate</NavLink>
         </div>
      </div>
   </div>
</nav>);
    }
}

function mapStateToProps(state) {
	// authentication part code has to be done
 
    return {
    
    };
}

const connectedHeaderPage = connect(mapStateToProps)(HeaderPage);
export { connectedHeaderPage as HeaderPage};