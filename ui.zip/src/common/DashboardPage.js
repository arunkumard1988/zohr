import React, { Component } from 'react';
import { Link,Switch,Router, Route } from 'react-router-dom';
import { history } from '../helpers';
//import { alertActions } from '../_actions';
//import { PrivateRoute } from '../_components';
import { HeaderPage } from './HeaderPage';
import { HomePage } from '../components/HomePage/HomePage';
import { OnboardingPage } from '../components/OnboardingPage';
import {NotFoundPage} from '../components/NotFoundPage';
//import logo from './assets/images/logo.svg';
//import './assets/styles/css/app.css';
class DashboardPage extends Component {
  render() {	 
    return ( 
		<div>		
			<HeaderPage/>
			<Switch>
					<Route path="/HomePage" component={HomePage} />                                               
					<Route path="/Onboarding" component={OnboardingPage} />
			</Switch>					
		</div>	
		
    );
  }
}
 
export default DashboardPage;
