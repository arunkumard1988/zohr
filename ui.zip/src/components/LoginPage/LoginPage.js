import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import logo from './../../assets/images/deluxe-red.svg'; 
import './../../assets/styles/css/app.css';
import './../../assets/styles/css/bulma.min.css';
import { history } from '../../helpers';
class LoginPage extends React.Component {
    constructor(props) {
        super(props);      
        this.state = {
            username: '',
            upassword: '',
            submitted: false 
        };
		//this.props.headingText="hidden";
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }
    
    handleChange(e) {
        const { name, value } = e.target;
        this.setState({ [name]: value });
    }

    handleSubmit(e) {
        e.preventDefault();

        this.setState({ submitted: true });
        const { username } = this.state;
        const { upassword } = this.state;
        //const { dispatch } = this.props;
		//	this.transitionTo('home');
		if (username) {
			history.push("/HomePage");

		}
    }
    
    render() {
        //const { loggingIn } = this.props;
        const { username,upassword, submitted } = this.state;
		return (<div>							 
						<div className="container is-fluid content-wrapper">
						<section className="section">
							<h1 className="title has-text-centered">LOGIN</h1>							 
							<div className="columns">
								<div className="column">
									<div className="card onboarding">
										<div className="card-content">
											<form name="form" onSubmit={this.handleSubmit} className="tenant-login">												 
												<div className={'field' + (submitted && !username ? ' has-text-danger' : '')}>
													<label className="label">User Name</label>
													<div className="control">														 
														<input type="text" className="input" name="username" value={username} onChange={this.handleChange} placeholder="Enter User Name" autoComplete="off"/>
														{submitted && !username &&
															<div className="help-block">User Name is required</div>
														}														
													</div>													 
												</div><div className={'field' + (submitted && !upassword ? ' has-text-danger' : '')}>
													<label className="label">Password</label>
													<div className="control">														 
														<input type="password" className="input" name="upassword" value={upassword} onChange={this.handleChange} placeholder="Enter Password" autoComplete="off"/>
														{submitted && !upassword &&
															<div className="help-block">Password is required</div>
														}
												</div>
												</div>
												<div className="control">
													<button className="button is-primary is-fullwidth">Start</button>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</section>
					</div>
					</div>
					
           
        );
    }
}

function mapStateToProps(state) {
	// authentication part code has to be done
   // const { loggingIn } = state.authentication;
    return {
     //   loggingIn
    };
}

const connectedLoginPage = connect(mapStateToProps)(LoginPage);
export { connectedLoginPage as LoginPage }; 