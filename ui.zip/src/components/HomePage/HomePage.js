import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
 
class HomePage extends React.Component {
    render() {
       // const { user, users } = this.props; 		
        return (
	<div>		 
	<div className="container is-fluid content-wrapper">
	<section className="section">
      <h1 className="title">Policy</h1>
      <div className="columns">
        <div className="column">
          <div className="card policy">
            <div className="card-content">
              <div className="filters columns">
                <div className="field column">                
                  <div className="control">
                    <div className="select">
                      <select>
                        <option  >Filter by ID</option>
                        <option>deluxe.auth.admin</option>
                        <option>deluxe.auth.admin</option>
                        <option>deluxe.auth.admin</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="field column">                  
                  <div className="control">
                    <div className="select">
                      <select>
                         <option>Filter by Description</option>
                        <option>deluxe.auth.admin</option>
                        <option>deluxe.auth.admin</option>
                        <option>deluxe.auth.admin</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="field column"> 
                  <div className="control">
                    <div className="select">
                      <select>
                         <option>Filter by Resource</option>
                        <option>auth:                          
                        </option>
                        <option>auth:                          
                        </option>
                        <option>auth:                          
                        </option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="field column">              
                  <div className="control">
                    <div className="select">
                      <select>
                         <option  >Filter by Action</option>
                        <option>GET</option>
                        <option>PUT</option>
                        <option>HEAD</option>
                        <option>POST</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="field column">
                  <div className="control">
                    <div className="select">
                      <select>
                         <option  >Filter by Subject</option>
                        <option>role:deluxe.auth.admin</option>
                        <option>role:deluxe.auth.admin</option>
                        <option>role:deluxe.auth.admin</option>
                        <option>role:deluxe.auth.admin</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="field column">                  
                  <div className="control">
                    <div className="select">
                      <select>
                        <option  >Filter by Condition</option>
                        <option>Lorem ipsum dolor sit</option>
                        <option>Amet consectetur adipisicing elit</option>
                        <option>Lorem ipsum dolor sit</option>
                      </select>
                    </div>
                  </div>
                </div>

              </div>
              <table className="table is-fullwidth">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Description</th>
                    <th>Resource(s)</th>
                    <th>Actions</th>
                    <th>Subjects</th>
                    <th>Effect</th>
                    <th>Conditions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>deluxe.auth.admin</td>
                    <td>admin of auth in realm deluxe</td>
                    <td>
                      <ul>
                        <li>auth:                         
                        </li>
                        <li>auth:                         
                        </li>
                        <li>auth:                         
                        </li>
                      </ul>
                    </td>
                    <td>
                      <ul>
                        <li>GET</li>
                        <li>PUT</li>
                      </ul>
                    </td>
                    <td>
                      <ul>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                      </ul>
                    </td>
                    <td>allow</td>
                    <td>
                      <ul>
                        <li>Lorem ipsum dolor sit</li>
                        <li>Amet consectetur adipisicing elit</li>
                        <li>Lorem ipsum dolor sit</li>
                      </ul>
                    </td>
                  </tr>

                  <tr>
                    <td>deluxe.auth.admin</td>
                    <td>admin of auth in realm deluxe</td>
                    <td>
                      <ul>
                        <li>auth:
                          
                        </li>
                        <li>auth:
                          
                        </li>
                        <li>auth:
                          
                        </li>
                      </ul>
                    </td>
                    <td>
                      <ul>
                        <li>GET</li>
                        <li>PUT</li>
                      </ul>
                    </td>
                    <td>
                      <ul>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                      </ul>
                    </td>
                    <td>allow</td>
                    <td>
                      <ul>
                        <li>Lorem ipsum dolor sit</li>
                        <li>Amet consectetur adipisicing elit</li>
                        <li>Lorem ipsum dolor sit</li>
                      </ul>
                    </td>
                  </tr>

                  <tr>
                    <td>deluxe.auth.admin</td>
                    <td>admin of auth in realm deluxe</td>
                    <td>
                      <ul>
                        <li>auth:
                          
                        </li>
                        <li>auth:
                          
                        </li>
                        <li>auth:
                          
                        </li>
                      </ul>
                    </td>
                    <td>
                      <ul>
                        <li>GET</li>
                        <li>PUT</li>
                      </ul>
                    </td>
                    <td>
                      <ul>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                      </ul>
                    </td>
                    <td>allow</td>
                    <td>
                      <ul>
                        <li>Lorem ipsum dolor sit</li>
                        <li>Amet consectetur adipisicing elit</li>
                        <li>Lorem ipsum dolor sit</li>
                      </ul>
                    </td>
                  </tr>

                  <tr>
                    <td>deluxe.auth.admin</td>
                    <td>admin of auth in realm deluxe</td>
                    <td>
                      <ul>
                        <li>auth:
                          
                        </li>
                        <li>auth:
                          
                        </li>
                        <li>auth:
                          
                        </li>
                      </ul>
                    </td>
                    <td>
                      <ul>
                        <li>GET</li>
                        <li>PUT</li>
                      </ul>
                    </td>
                    <td>
                      <ul>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                      </ul>
                    </td>
                    <td>allow</td>
                    <td>
                      <ul>
                        <li>Lorem ipsum dolor sit</li>
                        <li>Amet consectetur adipisicing elit</li>
                        <li>Lorem ipsum dolor sit</li>
                      </ul>
                    </td>
                  </tr>

                  <tr>
                    <td>deluxe.auth.admin</td>
                    <td>admin of auth in realm deluxe</td>
                    <td>
                      <ul>
                        <li>auth:
                          
                        </li>
                        <li>auth:
                          
                        </li>
                        <li>auth:
                          
                        </li>
                      </ul>
                    </td>
                    <td>
                      <ul>
                        <li>GET</li>
                        <li>PUT</li>
                      </ul>
                    </td>
                    <td>
                      <ul>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                      </ul>
                    </td>
                    <td>allow</td>
                    <td>
                      <ul>
                        <li>Lorem ipsum dolor sit</li>
                        <li>Amet consectetur adipisicing elit</li>
                        <li>Lorem ipsum dolor sit</li>
                      </ul>
                    </td>
                  </tr>

                  <tr>
                    <td>deluxe.auth.admin</td>
                    <td>admin of auth in realm deluxe</td>
                    <td>
                      <ul>
                        <li>auth:
                          
                        </li>
                        <li>auth:
                          
                        </li>
                        <li>auth:
                          
                        </li>
                      </ul>
                    </td>
                    <td>
                      <ul>
                        <li>GET</li>
                        <li>PUT</li>
                      </ul>
                    </td>
                    <td>
                      <ul>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                      </ul>
                    </td>
                    <td>allow</td>
                    <td>
                      <ul>
                        <li>Lorem ipsum dolor sit</li>
                        <li>Amet consectetur adipisicing elit</li>
                        <li>Lorem ipsum dolor sit</li>
                      </ul>
                    </td>
                  </tr>

                  <tr>
                    <td>deluxe.auth.admin</td>
                    <td>admin of auth in realm deluxe</td>
                    <td>
                      <ul>
                        <li>auth:
                          
                        </li>
                        <li>auth:
                          
                        </li>
                        <li>auth:
                          
                        </li>
                      </ul>
                    </td>
                    <td>
                      <ul>
                        <li>GET</li>
                        <li>PUT</li>
                      </ul>
                    </td>
                    <td>
                      <ul>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                        <li>role:deluxe.auth.admin</li>
                      </ul>
                    </td>
                    <td>allow</td>
                    <td>
                      <ul>
                        <li>Lorem ipsum dolor sit</li>
                        <li>Amet consectetur adipisicing elit</li>
                        <li>Lorem ipsum dolor sit</li>
                      </ul>
                    </td>
                  </tr>


                </tbody>
              </table>

              <nav className="pagination" role="navigation" aria-label="pagination">
                <a className="pagination-previous">Previous</a>
                <a className="pagination-next">Next page</a>
                <ul className="pagination-list">
                  <li>
                    <a className="pagination-link" aria-label="Goto page 1">1</a>
                  </li>
                  <li>
                    <span className="pagination-ellipsis">&hellip;</span>
                  </li>
                  <li>
                    <a className="pagination-link" aria-label="Goto page 45">45</a>
                  </li>
                  <li>
                    <a className="pagination-link is-current" aria-label="Page 46" aria-current="page">46</a>
                  </li>
                  <li>
                    <a className="pagination-link" aria-label="Goto page 47">47</a>
                  </li>
                  <li>
                    <span className="pagination-ellipsis">&hellip;</span>
                  </li>
                  <li>
                    <a className="pagination-link" aria-label="Goto page 86">86</a>
                  </li>
                </ul>
              </nav>
            </div>
          </div>


        </div>
      </div>
    </section>				 
				</div>	 
				</div>	 
        );
    }
}

function mapStateToProps(state) {
	// authentication part code has to be done
 
    return {
    
    };
}

const connectedHomePage = connect(mapStateToProps)(HomePage);
export { connectedHomePage as HomePage };