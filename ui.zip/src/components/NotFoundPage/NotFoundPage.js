import React from 'react';
import { connect } from 'react-redux';
 
class NotFoundPage extends React.Component {
    render() {
       // const { user, users } = this.props; 		
        return (		
		<div>
		<div className="container is-fluid content-wrapper">
					<div className="flex-grid">
					<div className="panel flex-col pnf-panel">
					<div className="pnf-card">
					<div className="pnf-card__404-text">
						<h2>404</h2>
						<h3>Page Not Found</h3>
						<p>Hi User !! The Requested Page was not Found !!</p>
					</div>
					</div>
					</div>
					</div>
					</div>
					</div>
        );
    }
}

function mapStateToProps(state) {
	// authentication part code has to be done
 
    return {
    
    };
}

const connectedNotFoundPage = connect(mapStateToProps)(NotFoundPage);
export { connectedNotFoundPage as NotFoundPage};