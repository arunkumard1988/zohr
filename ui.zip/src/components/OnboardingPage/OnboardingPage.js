import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import logo from './../../assets/images/deluxe-red.svg'; 
import { history } from '../../helpers';
import { onboardingActions } from '../../state/actions';

class OnboardingPage extends React.Component {
    constructor(props) {
        super(props);      
        this.state = {
            realmname: '',
            servicename: '',
			submitted: false,
			realmIn:''
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(e) {
        const { name, value } = e.target;
        this.setState({ [name]: value });
    }

    handleSubmit(e) {
        e.preventDefault();
		this.setState({ submitted: true });		
        const { realmname } = this.state;
		const { servicename } = this.state;
		const { dispatch } = this.props;		
		if (realmname) {
			this.setState({ realmIn: true });
			dispatch(onboardingActions.addService(realmname,realmname));
			setTimeout(() => this.setState({ realmIn: '',isRealmSuccess:true }), 1500);
		}
    }

    render() {
        const { realmIn } = this.state;
		const { realmname,servicename, submitted } = this.state;
		const { isRealmSuccess } = this.state;		
		console.log(realmIn); 	
        return (<div>	 		 
					<div className="container is-fluid content-wrapper">
						<section className="section">
							<h1 className="title has-text-centered">Onboarding</h1>
							<div className="columns">
								<div className="column">
									<div className="card onboarding">
										<div className="card-content">
											<form name="form" onSubmit={this.handleSubmit} className="tenant-login">												 
												<div className={'field' + (submitted && !realmname ? ' has-text-danger' : '')}>
													<label className="label">Enter Realm Name</label>
													<div className="control">			
												 
                            								 
														<input type="text" className="input" name="realmname" value={realmname} onChange={this.handleChange} placeholder="Enter Realm Name" autoComplete="off"/>
														{realmIn ?
														<img src="data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==" />
														:''}
														{submitted && !realmname &&
															<div className="help-block">Realm Name is required</div>
														}
															<div><input type="checkbox"/> Include default services and roles	</div>													
													</div>	
																									 
												</div>											 
												{isRealmSuccess ? <div className={'field' + (submitted && !servicename  ? ' has-text-danger' : '')}>
													<label className="label">Enter Service Name</label>
													<div className="control">														 
														<input type="password" className="input" name="servicename" value={servicename} onChange={this.handleChange} placeholder="Enter Service Name" autoComplete="off"/>
														{submitted && !servicename  && (isRealmSuccess!=true) &&
															<div className="help-block">Service Name is required</div>
														}
												</div>
												</div>:null}
												<div className="control">
													<button className="button is-primary is-fullwidth">Start</button>																							
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</section>
					</div>
					</div>
					
           
        );
    }
}

function mapStateToProps(state) {
	// authentication part code has to be done
     const { realmIn } = state;
    return {
        realmIn
    };
}

const connectedOnboardingPage = connect(mapStateToProps)(OnboardingPage);
export { connectedOnboardingPage as OnboardingPage }; 