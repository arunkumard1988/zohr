import React from 'react';
import { ReactDOM,render } from 'react-dom';
import { Provider } from 'react-redux';
import { store } from './helpers';
import App from './App';
//configureFakeBackend();
import './assets/styles/css/index.css';
import './assets/styles/scss/main.css';
//import registerServiceWorker from './registerServiceWorker';
render(
    <Provider store={store}>
        <App />
    </Provider>,
    document.getElementById('root')
);
//ReactDOM.render(<App />, document.getElementById('root'));
//registerServiceWorker();
