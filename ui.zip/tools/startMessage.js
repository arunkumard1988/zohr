import colors from 'colors';

/* eslint-disable no-console */

console.log('Starting app in dev mode...'.green); 

